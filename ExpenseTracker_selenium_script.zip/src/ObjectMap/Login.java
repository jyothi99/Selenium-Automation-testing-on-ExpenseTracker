package ObjectMap;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {
    WebDriver driver;
    By loginusername=By.xpath("/html/body/div/div/form/input[1]");
    By loginpassword=By.xpath("/html/body/div/div/form/input[2]");
    By loginbutton=By.xpath("/html/body/div/div/form/button");
    By SignUpbutton=By.xpath("/html/body/div/div/button[1]");
    By skip=By.xpath("/html/body/div/div/button[2]");
    public Login(WebDriver driver) 
    {
       this.driver=driver;
     }
    public void login_username(String uname)
    {
    	driver.findElement(loginusername).clear();
        driver.findElement(loginusername).sendKeys(uname);
     }
     public void login_password(String pswd) {
    	 driver.findElement(loginpassword).clear();
        driver.findElement(loginpassword).sendKeys(pswd);
     }
    public void login_button()
    {
       driver.findElement(loginbutton).click();
       driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }
    public void signup_button()
    {
       driver.findElement(SignUpbutton).click();
       driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }
    public void skip_button() {
    	driver.findElement(skip).click();
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }
}
