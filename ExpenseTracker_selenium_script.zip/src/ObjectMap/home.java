package ObjectMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home {
    WebDriver driver;
    By salary=By.name("salary");
    By other=By.name("other");
    By own=By.xpath("/html/body/section/article/div/form/input[3]");
    By rented=By.xpath("/html/body/section/article/div/form/input[4]");
    By rent=By.name("rent");
    By oth=By.name("other home");
    //By drop=By.xpath("/html/body/div/div/button[1]");
    By tamount=By.name("transport");
    By eamount=By.name("edu");
    By famount=By.name("amt");
    By goal=By.name("limit");
    By submit=By.xpath("/html/body/section/article/div/form/input[16]");
    public home(WebDriver driver) 
    {
       this.driver=driver;
     }
    public void salary_field(String sal)
    {
    	 driver.findElement(salary).clear();
        driver.findElement(salary).sendKeys(sal);
        
     }
    public void other_field(String othincome)
    {
    	driver.findElement(other).clear();
        driver.findElement(other).sendKeys(othincome);
       
     }
    public void own_field()
     {
         driver.findElement(own).click();
      }
    public void rented_field()
      {
          driver.findElement(rented).click();
       }
    public void rent_field(String rnt)
       {
    	driver.findElement(rent).clear();
           driver.findElement(rent).sendKeys(rnt);
           
        }
    public String get_att(String a) {
    	return driver.findElement(rent).getAttribute(a);
    }
    public void oth_field(String othr)
        {
    	driver.findElement(oth).clear();
            driver.findElement(oth).sendKeys(othr);
            
         }
    public void tamt_field(String tt)
         {
    	driver.findElement(tamount).clear();
             driver.findElement(tamount).sendKeys(tt); 
           
         }
    public void eamt_field(String emt)
          {
    	driver.findElement(eamount).clear();
              driver.findElement(eamount).sendKeys(emt);
             
           }
    public void famt_field(String fmt)
    {
    	driver.findElement(famount).clear();
        driver.findElement(famount).sendKeys(fmt);
        
     }
    public void goal_field(String sav)
    {
    	driver.findElement(goal).clear();
        driver.findElement(goal).sendKeys(sav);
        
     }
    public void sub_field()
    {
        driver.findElement(submit).click();
     }
    
}