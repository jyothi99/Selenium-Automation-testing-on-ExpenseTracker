
package ObjectMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class signup {
    WebDriver driver;
    By signupusername=By.name("username");
    By signuppassword=By.name("pswd");
    By repassword=By.name("repswd");
    By SignUpbutton=By.xpath("/html/body/div/div/form/button");
   
    public signup(WebDriver driver) 
    {
       this.driver=driver;
     }
    public void signup_username(String username)
     {
    	driver.findElement(signupusername).clear();
         driver.findElement(signupusername).sendKeys(username);
      }
      public void signup_password(String pass) {
    	  driver.findElement(signuppassword).clear();
         driver.findElement(signuppassword).sendKeys(pass);
      }
      public void signup_repassword(String repass) {
    	  driver.findElement(repassword).clear();
          driver.findElement(repassword).sendKeys(repass);
       }
    
    public void signup_button()
    {
       driver.findElement(SignUpbutton).click();
    }
}
