package TestCase;

import java.awt.AWTException;
import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Library.WrapperEx;
import ObjectMap.Login;
import TestData.fieldvalid;

public class LoginFieldValidationTestcases extends WrapperEx{
	fieldvalid fv=new fieldvalid();
	
	@Test
	  public void tc_21() throws IOException 
	  {
		 Login l=new Login(driver);
		  l.login_username(fv.data2(0, 0));    
	  }
	@Test
	 public void tc_22() throws IOException 
	  {
		Login l=new Login(driver);
		l.login_username(fv.data2(1, 0));
	  }
	@Test
	  public void tc_23() throws IOException 
		  {
		Login l=new Login(driver);
		l.login_username(fv.data2(2, 0));
		  }
		
	@Test
	public void tc_24() throws IOException 
			  {
		Login l=new Login(driver);
		  l.login_password(fv.data2(0, 1));
		  Reporter.log("expected error when password less than 8 characters");
		  Assert.fail();
			  }
		
@Test
public void tc_25() throws IOException 
				  {
	Login l=new Login(driver);
	 l.login_password(fv.data2(1, 1));
				  }
	
		@Test
		
public void tc_26() throws IOException 
					  {
			Login l=new Login(driver);
			l.login_password(fv.data2(2, 1));
			Reporter.log("expected error when password greater than 8 characters");
			 Assert.fail();
					  }
			
		
	  @BeforeClass
	  public void startUp() 
	  {
	         launchApplication("chrome","http://localhost:8080/Expense%20Tracker/login.jsp" );                     
	  
	}

	@AfterClass
	public void close() {
	  quit();
	}
}
