package TestCase;

import java.awt.AWTException;
import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Library.WrapperEx;
import ObjectMap.signup;
import TestData.fieldvalid;

public class signupFieldValidationTestcases extends WrapperEx{
	fieldvalid fv=new fieldvalid();
	
	@Test
	  public void tc_12() throws IOException 
	  {
		 
		 // driver.findElement(By.name("pswd")).clear();
		  //driver.findElement(By.name("repswd")).clear();
		  signup l=new signup(driver);
		  l.signup_username(fv.data2(0, 0));    
	  }
	@Test
	 public void tc_13() throws IOException 
	  {
		signup l=new signup(driver);
		l.signup_username(fv.data2(1, 0));
	  }
	@Test
	  public void tc_14() throws IOException 
		  {
		signup l=new signup(driver);
		l.signup_username(fv.data2(2, 0));
		  }
		
	@Test
	public void tc_15() throws IOException 
			  {
		signup l=new signup(driver);
		  l.signup_password(fv.data2(0, 1));
		  Reporter.log("expected error when password less than 8 characters");
		  Assert.fail();
			  }
		
@Test
public void tc_16() throws IOException 
				  {
	signup l=new signup(driver);
	 l.signup_password(fv.data2(1, 1));
				  }
	
		@Test
		
		public void tc_17() throws IOException 
					  {
			signup l=new signup(driver);
			l.signup_password(fv.data2(2, 1));
			Reporter.log("expected error when password greater than 8 characters");
			 Assert.fail();
					  }
			
		@Test
		public void tc_18() throws IOException 
						  {
			signup l=new signup(driver);
			l.signup_repassword(fv.data2(0, 1));
			Reporter.log("expected error when password less than 8 characters");
			 Assert.fail();
			
					  }
		@Test
		public void tc_19() throws IOException 
						  {
			signup l=new signup(driver);
			l.signup_repassword(fv.data2(1, 1));
					  }
		
		@Test
		public void tc_20() throws IOException 
						  {
			signup l=new signup(driver);
			l.signup_repassword(fv.data2(2, 1));
			Reporter.log("expected error when password greater than 8 characters");
			 Assert.fail();
					  }
		
		
	  @BeforeClass
	  public void startUp() 
	  {
	         launchApplication("chrome","http://localhost:8080/Expense%20Tracker/signup.jsp" );                     
	  
	}

	@AfterClass
	public void close() {
	  quit();
	}
}
