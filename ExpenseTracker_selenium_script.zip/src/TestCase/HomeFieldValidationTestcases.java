package TestCase;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Library.WrapperEx;
import ObjectMap.Login;
import ObjectMap.home;
import TestData.HomeTestData;
import TestData.Logindata;

public class HomeFieldValidationTestcases extends WrapperEx{
	HomeTestData ex2=new HomeTestData();
  @Test
  public void tc_27() throws IOException
  {
		 home h=new home(driver);
		 int i=4;
         h.salary_field(ex2.data1(i,0));
         h.other_field(ex2.data1(i,1));
         h.own_field();
         h.rent_field(ex2.data1(i,2)); 
         h.oth_field(ex2.data1(i,3));
         h.tamt_field(ex2.data1(i,4));
         h.eamt_field(ex2.data1(i,5)); 
         h.famt_field(ex2.data1(i,6));
         h.goal_field(ex2.data1(i,7));
         h.sub_field();
         if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
        	  Reporter.log("expected meets actual");
         }else {
        	 Assert.fail();
         }
         //driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
  }
 @Test
 public void tc_28() throws IOException {
	 		driver.navigate().back();
	 		home h=new home(driver);
			 int i=5;
	         h.salary_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("salary")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_29() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=6;
	         h.salary_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("salary")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	          Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 
 @Test
 public void tc_30() throws IOException
 {
	 
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,0));
        h.own_field();
        h.rent_field(ex2.data1(i,2)); 
        h.oth_field(ex2.data1(i,3));
        h.tamt_field(ex2.data1(i,4));
        h.eamt_field(ex2.data1(i,5)); 
        h.famt_field(ex2.data1(i,6));
        h.goal_field(ex2.data1(i,7));
        h.sub_field();
        if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
       	 Reporter.log("expected meets actual");
        }else {
       	 Assert.fail();
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
 @Test
 public void tc_31() throws IOException {
	 		driver.navigate().back();
	 		home h=new home(driver);
			 int i=5;
	         h.other_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("other")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_32() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=6;
	         h.other_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("other")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	          Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_33() throws IOException {
	 	
	 		home h=new home(driver);
			 int i=5;
	         h.rent_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("rent")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_34() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=6;
	         h.rent_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("rent")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	         Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_35() throws IOException {
	 	
	 		home h=new home(driver);
			 int i=5;
	         h.oth_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("other home")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_36() throws IOException {
	 	
	 		home h=new home(driver);
			 int i=6;
	         h.oth_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("other home")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        
	        	 Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_37() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=5;
	         h.tamt_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("transport")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_38() throws IOException {
	 	
	 		home h=new home(driver);
			 int i=6;
	         h.tamt_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("transport")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	         
	        	 Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_39() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=5;
	         h.eamt_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("edu")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_40() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=6;
	         h.eamt_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("edu")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	         Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_41() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=5;
	         h.famt_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("amt")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_42() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=6;
	         h.famt_field(ex2.data1(i,0)); 
	         if(driver.findElement(By.name("amt")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 0))) {
	          Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_43() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=5;
	         h.goal_field(ex2.data1(i,7)); 
	         if(driver.findElement(By.name("limit")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 7))) {
	        	 Reporter.log("expected meets actual");
	         }else {
	        	 Assert.fail();
	         }
 }
 @Test
 public void tc_44() throws IOException {
	 		
	 		home h=new home(driver);
			 int i=6;
	         h.goal_field(ex2.data1(i,7)); 
	         if(driver.findElement(By.name("limit")).getAttribute("value").equalsIgnoreCase(ex2.data1(i, 7))) {
	          Assert.fail();
	         }else {
	        	 Reporter.log("expected meets actual");
	         }
 }
 @Test
 public void tc_45() throws IOException
 {
	 
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,1));
        h.own_field();
        h.rent_field(ex2.data1(i,0)); 
        h.oth_field(ex2.data1(i,3));
        h.tamt_field(ex2.data1(i,4));
        h.eamt_field(ex2.data1(i,5)); 
        h.famt_field(ex2.data1(i,6));
        h.goal_field(ex2.data1(i,7));
        h.sub_field();
        if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
       	 Reporter.log("expected meets actual");
        }else {
       	 Assert.fail();
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
 @Test
 public void tc_46() throws IOException
 {
	 driver.navigate().back();
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,1));
        h.own_field();
        h.rent_field(ex2.data1(i,2)); 
        h.oth_field(ex2.data1(i,0));
        h.tamt_field(ex2.data1(i,4));
        h.eamt_field(ex2.data1(i,5)); 
        h.famt_field(ex2.data1(i,6));
        h.goal_field(ex2.data1(i,7));
        h.sub_field();
        if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
       	 Reporter.log("expected meets actual");
        }else {
       	 Assert.fail();
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
 @Test
 public void tc_47() throws IOException
 {
	 driver.navigate().back();
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,1));
        h.own_field();
        h.rent_field(ex2.data1(i,2)); 
        h.oth_field(ex2.data1(i,3));
        h.tamt_field(ex2.data1(i,0));
        h.eamt_field(ex2.data1(i,5)); 
        h.famt_field(ex2.data1(i,6));
        h.goal_field(ex2.data1(i,7));
        h.sub_field();
        if(driver.getTitle().equalsIgnoreCase("home")) {
        	Assert.fail();
        }else {
       	 Reporter.log("expected meets actual");
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
 @Test
 public void tc_48() throws IOException
 {
	 driver.navigate().back();
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,1));
        h.own_field();
        h.rent_field(ex2.data1(i,2)); 
        h.oth_field(ex2.data1(i,3));
        h.tamt_field(ex2.data1(i,4));
        h.eamt_field(ex2.data1(i,0)); 
        h.famt_field(ex2.data1(i,6));
        h.goal_field(ex2.data1(i,7));
        h.sub_field();
        if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
       	 Reporter.log("expected meets actual");
        }else {
       	 Assert.fail();
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
 @Test
 public void tc_49() throws IOException
 {
	 driver.navigate().back();
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,1));
        h.own_field();
        h.rent_field(ex2.data1(i,2)); 
        h.oth_field(ex2.data1(i,3));
        h.tamt_field(ex2.data1(i,4));
        h.eamt_field(ex2.data1(i,5)); 
        h.famt_field(ex2.data1(i,0));
        h.goal_field(ex2.data1(i,7));
        h.sub_field();
        if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
       	 Reporter.log("expected meets actual");
        }else {
       	 Assert.fail();
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
 @Test
 public void tc_50() throws IOException
 {
	 driver.navigate().back();
		 home h=new home(driver);
		 int i=4;
        h.salary_field(ex2.data1(i,1));
        h.other_field(ex2.data1(i,1));
        h.own_field();
        h.rent_field(ex2.data1(i,2)); 
        h.oth_field(ex2.data1(i,3));
        h.tamt_field(ex2.data1(i,4));
        h.eamt_field(ex2.data1(i,5)); 
        h.famt_field(ex2.data1(i,6));
        h.goal_field(ex2.data1(i,0));
        h.sub_field();
        if(driver.findElement(By.id("invalid")).getAttribute("value").equalsIgnoreCase("Invalid")) {
       	 Reporter.log("expected meets actual");
        }else {
       	 Assert.fail();
        }
        driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
 }
  @BeforeClass
  public void startUp() 
  {
         launchApplication("chrome","http://localhost:8080/Expense%20Tracker/home.jsp" );                     
  
}

@AfterClass
public void close() {
  quit();
}
  
}
