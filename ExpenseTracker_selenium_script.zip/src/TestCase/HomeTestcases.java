package TestCase;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Library.WrapperEx;
import ObjectMap.Login;
import ObjectMap.home;
import TestData.HomeTestData;
import TestData.Logindata;

public class HomeTestcases extends WrapperEx{
	HomeTestData ex2=new HomeTestData();
  @Test
  public void tc_08() throws IOException
  {
		 home h=new home(driver);
		 int i=0;
         h.salary_field(ex2.data1(i,0));
         h.other_field(ex2.data1(i,1));
         h.own_field();
         h.rent_field(ex2.data1(i,2)); 
         h.oth_field(ex2.data1(i,3));
         h.tamt_field(ex2.data1(i,4));
         h.eamt_field(ex2.data1(i,5)); 
         h.famt_field(ex2.data1(i,6));
         h.goal_field(ex2.data1(i,7));
         h.sub_field();
         driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
  }
  @Test
  public void tc_09() throws IOException
  {
		 home h=new home(driver);
		 int i=0;
         h.salary_field(ex2.data1(i,0));
         h.other_field(ex2.data1(i,1));
         h.rented_field();
         h.rent_field(ex2.data1(i,2)); 
         h.oth_field(ex2.data1(i,3));
         h.tamt_field(ex2.data1(i,4));
         h.eamt_field(ex2.data1(i,5)); 
         h.famt_field(ex2.data1(i,6));
         h.goal_field(ex2.data1(i,7));
         h.sub_field();
         driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
  }
	
  @Test
  public void tc_10() throws IOException
  {
	     driver.navigate().back();
		 home h=new home(driver);
		 int i=1;
         h.salary_field(ex2.data1(i,0));
         h.other_field(ex2.data1(i,1));
         h.own_field();
         h.rent_field(ex2.data1(i,2)); 
         h.oth_field(ex2.data1(i,3));
         h.tamt_field(ex2.data1(i,4));
         h.eamt_field(ex2.data1(i,5)); 
         h.famt_field(ex2.data1(i,6));
         h.goal_field(ex2.data1(i,7));
         h.sub_field();
         driver.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);
  }
	
  @Test
  public void tc_11() throws IOException
  {
	  	 driver.navigate().back();
		 home h=new home(driver);
		 int i=2;
         h.salary_field(ex2.data1(i,0));
         h.other_field(ex2.data1(i,1));
         h.own_field();
         h.rent_field(ex2.data1(i,2)); 
         Reporter.log("expected rent updated with 0 in frontend");
         Assert.assertTrue(driver.findElement(By.name("rent")).getAttribute("value")=="0");
        // Assert.assertEquals(h.get_att(ex2.data1(1, 2)), "0");
       //assertEquals(0,h.get_att(ex2.data1(1, 2)));
         
         h.oth_field(ex2.data1(i,3));
         h.tamt_field(ex2.data1(i,4));
         h.eamt_field(ex2.data1(i,5)); 
         h.famt_field(ex2.data1(i,6));
         h.goal_field(ex2.data1(i,7));
         h.sub_field();
         
  }
  @BeforeClass
  public void startUp() 
  {
         launchApplication("chrome","http://localhost:8080/Expense%20Tracker/home.jsp" );                     
  
}

@AfterClass
public void close() {
  quit();
}
  
}
