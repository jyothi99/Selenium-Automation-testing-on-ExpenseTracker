package TestCase;

import java.awt.AWTException;
import java.io.IOException;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Library.WrapperEx;
import ObjectMap.Login;
import ObjectMap.signup;
import TestData.signupdata;

public class SignupTestcases extends WrapperEx{
	
	signupdata ex=new signupdata();
	int row=ex.row;
	int col=ex.col;
	
  @Test(priority=1)
  public void tc_01()
  {
         
		Login lpage=new Login(driver);
        lpage.signup_button();
  }
  
  @Test(priority=2)
  public void tc_02() throws IOException
  {
	  	
	  signup l=new signup(driver);
		 for(int i=0;i<=row;i++) {
			 for(int j=0;j<=col;j++) {
         l.signup_username(ex.data(i,j));
         l.signup_password(ex.data(i,j));
         l.signup_repassword(ex.data(i,j));
         l.signup_button();
			 }
		 }
  }
  @Test(priority=3)
  public void tc_03() throws AWTException, IOException
  {
	  driver.navigate().back();
	  //driver.findElement(signupusername).clear();
	 // driver.findElement(By.name("pswd")).clear();
	  //driver.findElement(By.name("repswd")).clear();
	  signup l=new signup(driver);
	  l.signup_username(ex.data(1, 0));
	  l.signup_password(ex.data(1, 1));
	  l.signup_repassword(ex.data(1, 2));
      l.signup_button();
      if(driver.getTitle().equalsIgnoreCase("welcome")) {
        	 System.out.println("testcase 3 failed");
         }
        
  }
  @Test(priority=3)
  public void tc_04() throws AWTException, IOException
  {
	  driver.navigate().back();
	  //driver.findElement(signupusername).clear();
	 // driver.findElement(By.name("pswd")).clear();
	  //driver.findElement(By.name("repswd")).clear();
	  signup l=new signup(driver);
	  l.signup_username(ex.data(2, 0));
	  l.signup_password(ex.data(2, 1));
	  Reporter.log("expected error 'username already exists' ");
      Assert.assertTrue(driver.findElement(By.name("username")).getAttribute("value")==ex.data(1, 0));
	  l.signup_repassword(ex.data(2, 2));
      l.signup_button();
  
  }
  @BeforeClass
	  public void startUp() 
      {
             launchApplication("chrome","http://localhost:8080/Expense%20Tracker/login.jsp" );                     
      
  }

  @AfterClass
  public void close() {
      quit();
}

}
