package TestCase;

import java.io.IOException;

import org.junit.AfterClass;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Library.WrapperEx;
import ObjectMap.Login;
import TestData.Logindata;

public class LoginTestcases extends WrapperEx{
	Login lg=new Login(driver);
	Logindata ex1=new Logindata();
	int row=ex1.row;
	int col=ex1.col;
	
	@Test(priority=1)
public void tc_05() {
	Login lg=new Login(driver);
	lg.skip_button();
	if(driver.getTitle().equalsIgnoreCase("welcome")) {
   	 //System.out.println("testcase 4 failed");
	Reporter.log("testcase 4 failed");
    }
}
	
	@Test(priority=2)
  public void tc_06() throws IOException
  {
		Login lg=new Login(driver);
		 driver.navigate().back();
		 for(int i=0;i<=row;i++) {
			 for(int j=0;j<=col;j++) {
         lg.login_username(ex1.data1(i,j));
         lg.login_password(ex1.data1(i,j));
         lg.login_button();
			 }
		 }
  }
	@Test(priority=3)
	  public void tc_07() throws IOException
	  {
			Login lg=new Login(driver);
			 driver.navigate().back();
			
	         lg.login_username(ex1.data1(1,0));
	         lg.login_password(ex1.data1(1,1));
	         lg.login_button();        
			 
	  }
  @BeforeClass
  public void startUp() 
  {
         launchApplication("chrome","http://localhost:8080/Expense%20Tracker/login.jsp" );                     
  
}

@AfterClass
public void close() {
  quit();
}

}
