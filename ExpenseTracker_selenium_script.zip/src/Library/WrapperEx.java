package Library;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WrapperEx {
public WebDriver driver;
       
              public void launchApplication(String browser,String url) {
                     try
                     {
                           if(browser.equalsIgnoreCase("firefox")) {
                                  driver=new FirefoxDriver();
                                  }
                           else if(browser.equalsIgnoreCase("chrome")) {
                                  System.setProperty("webdriver.chrome.driver","D:\\Chrome Drivers\\chromedriver_2.45\\chromedriver.exe");
                                  driver=new ChromeDriver();
                           }
                           driver.manage().window().maximize();
                           driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
                           driver.get(url);
              }
                     catch(WebDriverException e) {
                           System.out.println("browser could not be launched");
                 
                     }
              }

            public void quit(){
                     driver.close();
              }

}
