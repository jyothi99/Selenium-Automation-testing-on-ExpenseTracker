package TestData;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Logindata {
	public int row;
	public int col;

	public String data1(int rowcount,int columncount) throws IOException {
FileInputStream fil=new FileInputStream("D:\\testdata\\login.xlsx");
XSSFWorkbook workbook=new XSSFWorkbook(fil);
XSSFSheet sheet=workbook.getSheetAt(0);
row=sheet.getLastRowNum();
col=sheet.getDefaultColumnWidth();
//System.out.println(rowcount);
//for(int i=0;i<=rowcount;i++) {
XSSFRow row=sheet.getRow(rowcount);
XSSFCell cell=row.getCell(columncount);
String un=cell.getStringCellValue();

return un;
}
}